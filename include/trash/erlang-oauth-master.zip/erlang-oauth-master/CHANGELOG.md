# [v1.5.0](https://github.com/tim/erlang-oauth/tree/v1.5.0) (2014-07-25)

  * Added support for encoding binary terms as parameter values


# [v1.4.0](https://github.com/tim/erlang-oauth/tree/v1.4.0) (2013-07-21)

  * Added support for new crypto:hmac/3 function

  * Moved unit tests from github.com/tim/erlang-oauth-tests


# [v1.3.0](https://github.com/tim/erlang-oauth/tree/v1.3.0) (2012-09-13)

  * Added oauth:put/6 and oauth:put/7 functions


# [v1.2.2](https://github.com/tim/erlang-oauth/tree/v1.2.2) (2011-11-18)

  * Added support for new tagged tuple returned by http_uri:parse/1 (R15B)


# [v1.2.1](https://github.com/tim/erlang-oauth/tree/v1.2.1) (2011-10-17)

  * Updated to use a constant time algorithm to compare signature strings


# [v1.2.0](https://github.com/tim/erlang-oauth/tree/v1.2.0) (2011-06-23)

  * Added oauth:get/3 and oauth:post/3 functions

  * Collapsed into just a single module


# [v1.1.1](https://github.com/tim/erlang-oauth/tree/v1.1.1) (2011-01-29)

  * Updated to use the correct request parameter normalization algorithm


# [v1.1.0](https://github.com/tim/erlang-oauth/tree/v1.1.0) (2011-01-24)

  * Updated to use the new public key API introduced in R14B (public_key-0.8)


# [v1.0.2](https://github.com/tim/erlang-oauth/tree/v1.0.2) (2010-11-26)

  * Added oauth:get/6 and oauth:post/6 with additional HttpcOptions parameter


# [v1.0.1](https://github.com/tim/erlang-oauth/tree/v1.0.1) (2010-11-26)

  * First version numbered version!
