erl -pa ebin/ -name phpapp@`hostname` -s php
